import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import userRouter from "./Routers/userRouter.js";
import jwt from "jsonwebtoken";
import authenticateUser from "./middlewares/authentication.js";
import productRouter from "./Routers/productRouter.js";
import dotenv from "dotenv";
import orderRouter from "./Routers/orderRouter.js";


dotenv.config()
const app = express();
const mongodbURI = process.env.MONGO_URI
mongoose.connect(mongodbURI).then(
    ()=>{
        console.log("connected to mongoDB")
    }
).catch(
    (error)=>{
        console.error("MongoDB connection failed:", error.message)
    }
)

app.use(cors())
app.use(express.json())

app.use(authenticateUser)

app.use("/api/users" , userRouter)
app.use("/api/products" ,productRouter)
app.use("/api/orders" , orderRouter)
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log("server is running on port " + port);
});

